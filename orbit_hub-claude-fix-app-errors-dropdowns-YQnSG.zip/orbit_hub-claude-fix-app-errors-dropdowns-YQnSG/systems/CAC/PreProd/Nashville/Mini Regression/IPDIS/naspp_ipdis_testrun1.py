import os
import sys
import time
import re
from pathlib import Path
from playwright.sync_api import Playwright, sync_playwright, expect

# =========================================================
# Configuration
# =========================================================

SYSTEM      = "CAC"
ENVIRONMENT = "Pre-Production"
PILLAR      = "NFD"
RUN_TYPE    = "Mini Regression"
TEST_SET    = "IPDIS"

# =========================================================
# Bootstrap — locate project root and import shared runtime
# =========================================================

_env_root = os.environ.get("ORBIT_ROOT")
if _env_root:
    sys.path.insert(0, _env_root)
else:
    _p = Path(__file__).resolve()
    while _p.name.lower() not in ("orbit360",):
        if _p.parent == _p:
            raise RuntimeError("Could not locate Orbit project root.")
        _p = _p.parent
    sys.path.insert(0, str(_p))

from orbit360.backend.orbit_context import (
    setup, step, end_step, section_break,
    screenshot, manual_prompt, handle_failure, format_duration,
    crs_frame, start_trace, save_trace,
)
from orbit360.utils.orbit_frames import CACFrames

from orbit360.utils.orbit_script_helpers import (
    init_helpers,
    WAIT_PROFILES, DEFAULT_TIMEOUT, RETRY_COUNT,
    wait_with_intervention, wait_for_data_load,
    safe_click, safe_fill, safe_screenshot, step_with_pause,,
    pre_run_check,
)
ctx    = setup(SYSTEM, ENVIRONMENT, PILLAR, RUN_TYPE, TEST_SET)
logger = ctx.logger

init_helpers(ctx)

# Main Run
def run(playwright: Playwright) -> None:
    run_start_time = time.time()
    browser = None
    context = None
    page    = None
    page1   = None
    page2   = None
    # Patient profile values — assigned in the Profile step; safe to reference anywhere in run()
    admit_date = discharge_date = attending_md = admitting_md = referring_md = ""

    def _ctx(*fields):
        """Return a compact context hint for manual prompts, e.g. [Admit: 01/01 | Attending: Smith, J]"""
        labels = {
            "admit":      ("Admit",      lambda: admit_date),
            "discharge":  ("DC",         lambda: discharge_date),
            "attending":  ("Attending",  lambda: attending_md),
            "admitting":  ("Admitting",  lambda: admitting_md),
            "referring":  ("Referring",  lambda: referring_md),
        }
        parts = [f"{labels[f][0]}: {labels[f][1]()}" for f in fields if labels[f][1]()]
        return f"  [{' | '.join(parts)}]" if parts else ""
    try:
        pre_run_check("https://XRDCWTWEBCAC07B.HCA.CORPAD.NET/3M_360App")
        browser = playwright.chromium.launch(headless=False, args=["--start-maximized"])
        context = browser.new_context(no_viewport=True)
        start_trace(context)
        page = context.new_page()

    # ==================================================
    # Navigate to CAC Dashsboard
    # ==================================================
        section_break("CAC Dashboard")
        step("Nashville Pre-Production CAC Dashboard", "Launching Browser & Navigating to Dashboard")
        
        page.goto("https://XRDCWTWEBCAC07B.HCA.CORPAD.NET/3M_360App", wait_until="domcontentloaded")
        dashboard_anchor =  page.get_by_text("HIM Coding")
        safe_screenshot(page, dashboard_anchor, "cac_dashboard")

        end_step()
    # ==================================================
    # Navigate to Conurrent Coding Dashboard
    # ==================================================
        section_break("Concurrent Coding Dashboard")
        step("Check Concurrent Coding Dashboard Functionality", "Navigating to Concurrent Coding")

        concurrent_coding =  page.get_by_text("Concurrent Coding")
        safe_click(concurrent_coding, "Concurrent Coding")
        wait_for_data_load(page, "Concurrent Coding Page", profile="quick")
        end_step()
    # ==================================================
    # Navigate to Discharged All Worklist
    # ==================================================
        section_break("Discharged All Worklist")
        step("Open Discharged All Worklist", "Openging Discharged All Worklist")
        priority_anchor =  page.get_by_text("Discharged All", exact=True)
        safe_screenshot(page, priority_anchor, "concurrent_coding_dashboard")

        logger.info("Selecting Discharged All Worklist")
        worklist_btn =  page.get_by_text("Discharged All", exact=True)
        safe_click(worklist_btn, "Discharged All Worklist")
        wait_for_data_load(page, "Discharged All Worklist", profile="quick")
        
        end_step()
    # ==================================================
    # Manual Patient Selection
    # ==================================================  
        section_break("Select Patient Record")
        step("Select Patient", "Select a Patient Record")
        manual_prompt(
            message="Select a patient record",
            completion_note="Patient Selected"
        )

        end_step()
    # ==================================================
    # Patient Account
    # ==================================================  
        section_break("Patient Validation Check")
        step("Confirm Patient Loaded", "Patient Record Loaded")
        with page.expect_popup() as page1_info:
            pass
        page1 = page1_info.value
        page1.bring_to_front()
        frames = CACFrames(page1)
        patient_anchor =  page1.get_by_text("Documents and Codes")
        safe_screenshot(page1, patient_anchor, "patient_record")

        end_step()
    # ==================================================
    # Navigate to Documents and Codes Tab
    # ==================================================
        page1.wait_for_timeout(1000)
        page1.get_by_text("Documents and Codes").click()

    # ==================================================
    # Patient Profile — Record Dates & Physicians
    # ==================================================
        section_break("Patient Profile")
        step("Record Patient Profile Data", "Capturing admit/discharge dates and attending physicians")

        page1.wait_for_timeout(1000)
        page1.get_by_text("Patient Profile").click()
        page1.wait_for_timeout(1000)

        admit_date      = ctx.prompt_value("Admit Date (as shown on Patient Profile)")
        discharge_date  = ctx.prompt_value("Discharge Date (as shown on Patient Profile, or leave blank if not present)", default="")
        attending_md    = ctx.prompt_value("Attending Physician (last, first)")
        admitting_md    = ctx.prompt_value("Admitting Physician (last, first)")
        logger.info(f"Admitting: {admitting_md}")
        referring_md    = ctx.prompt_value("Referring Physician (last, first, or leave blank if none)", default="")

        logger.info(f"Admit: {admit_date} | Discharge: {discharge_date}")
        logger.info(f"Attending: {attending_md} | Admitting: {admitting_md} | Referring: {referring_md}")

        screenshot(page1, "patient_profile")
        page1.wait_for_timeout(1000)
        page1.get_by_text("Documents and Codes").click()

        end_step()

        # Check Help > About > Coding & Reimbursement
        section_break("About - Coding & Reimbursement")
        step("About - Coding & Reimbursement", "Checking Help - About - Coding & Reimbursement")
        page1.wait_for_timeout(1000)
        logger.info("Selecting Help Option")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_role("menuitem", name="Help").click()
        logger.info("Help Menu Open")
        logger.info("Selecting About")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_role("menuitem", name="About ➧").click()
        logger.info("Selecting Coding & Reimbursement")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_role("menuitemcheckbox", name="Coding & Reimbursement System").click()
        logger.info("Details Opened")
        screenshot(page1, "crs_version_details")
        logger.info("Closing CRS Version Window")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_role("button", name="OK").click()
        logger.info("Checking About - Computer Assisted Coding")
        
        end_step()
        # Check Help > About > Computer Assisted Coding
        section_break("About - Computer Assisted Coding")
        step("About - Computer Assisted Coding", "Checking Help - About - Computer Assisted Coding")
        page1.wait_for_timeout(1000)
        logger.info("Selecting Help Option")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_role("menuitem", name="Help").click()
        logger.info("Opening Help Menu & Selecting About")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_role("menuitem", name="About ➧").click()
        logger.info("Selecting Computer Assisted Coding")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("Computer Assisted Coding").click()
        logger.info("Details Opened")
        screenshot(page1, "cac_version_details")
        logger.info("Closing CRS Version Window")
        page1.wait_for_timeout(1000)
        frames.cac.get_by_role("button", name="OK").click()
        logger.info("Moving to Next Steps of Test")

        end_step()
        # Add Custom Actionable Edit (D630)
        section_break("Add Custom Actionable Edit - D630")
        step("Actionable Edit", "Add Custom Actionable Edit - D630")

        logger.info("Adding Diagnosis Code - D630")
        page1.wait_for_timeout(1000)
        frames.crs_inline.get_by_role("textbox", name="Enter Keyword or Code:").click()
        page1.wait_for_timeout(1000)
        frames.crs_inline.get_by_role("textbox", name="Enter Keyword or Code:").fill("D630")
        page1.wait_for_timeout(1000)
        frames.crs_inline.get_by_role("textbox", name="Enter Keyword or Code:").click()
        page1.wait_for_timeout(1000)
        frames.crs_inline.get_by_role("textbox", name="Enter Keyword or Code:").press("Enter")
        logger.info("Code Added")
        page1.wait_for_timeout(1000)
        frames.crs_inline.get_by_role("button", name="OK").click()
        page1.wait_for_timeout(1000)
        frames.crs_inline.get_by_text("Anemia in neoplastic disease").click(button="right")
        page1.wait_for_timeout(1000)
        frames.crs_inline.get_by_text("Copy Code as Primary").click() # Copy D630 Dx Code as Primary
        logger.info("Copied Admit Dx as Primary Diagnosis")
        screenshot(page1, "copied_admit_dx")
        page1.wait_for_timeout(1000)
        
        manual_prompt(
            message="Select Neoplasm",
            completion_note="Neoplasm Selected"
        )     

        # Work Through Remaining D630 Prompts (D499)
        logger.info("Working Through Remaining Prompts")
        page1.wait_for_timeout(1000)
        try:
            frames.crs_inline.get_by_role("radio", name="Unspecified").check()
            logger.info("Unspecified option selected")
        except Exception as e:
                logger.error(f"Unspecified option failed | {str(e)}")

                manual_prompt(
                    message="Unspecified Option could not be selected. Please fix it, then hit Continue in Orbit.",
                    completion_note="User handled Unspecified Option"
                )

        page1.wait_for_timeout(1000)
        frames.crs_inline.get_by_role("radio", name="Unspecified").check()
        page1.wait_for_timeout(1000)
        page1.pause()
        frames.codefinder.get_by_role("button", name="Continue").click()
        logger.info(" Diagnosis Code (D499) Added Successfully")
        screenshot(page1, "custom_edit_added")
        logger.info("Working Through Deleting Added Codes")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("PrincipalNeoplasm of").click()
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("PrincipalNeoplasm of").click(button="right")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("Delete Code(s)").click() # Delete Diagnosis Code (D499)
        logger.info("Diagnosis Code (D499) Deleted Successfully")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("PrincipalAnemia in neoplastic").click()
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("PrincipalAnemia in neoplastic").click(button="right")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("Delete Code(s)").click() # Delete Diagnosis Code (D630)
        page1.wait_for_timeout(1000)
        logger.info("Code (D630) Deleted Successfully")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("Anemia in neoplastic disease").click()
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("Anemia in neoplastic disease").click(button="right")
        page1.wait_for_timeout(1000)
        frames.codefinder.get_by_text("Delete Code(s)").click() # Delete Admit DX Code (D630)
        page1.wait_for_timeout(1000)
        logger.info("All Codes Successfully Deleted")
        screenshot(page1, "codes_removed")

        end_step()
        # Pop Out Codefinder
        section_break("Pop Out Codefinder")
        step("Pop Out Codefinder", "Popping Out Codefinder")
        logger.info("Selecting Pop Out Button")
        page1.wait_for_timeout(1000)
        page1.get_by_role("button", name=" Pop-out").click()

        # Prompt to Allow Pop Up
        manual_prompt(
            message="Click Allow Popup", 
            completion_note="Pop Out Window Opening"
        )  

        with page1.expect_popup() as page2_info:
            page2 = page2_info.value
            frames2 = CACFrames.for_popout(page2)
            logger.info("Page Popped Out")
            screenshot(page2, "pop_out_codefinder")
            
            end_step()
        # Code Account
            section_break("Code Account (Inpatient Esophagitis with Bleeding)")
            step("Code Account", "Add Codes to Account")

            logger.info("Adding Diagnosis Reason - K2090")
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").fill("K2090")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").press("Enter") # Add Admit DX Code (K2090)
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("button", name="OK").click()
            logger.info("Code (K2090) Added")
            logger.info("Adding Diagnosis Code - K2091")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("button", name="Add Diagnosis").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").fill("K2091")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").press("Enter") # Add Diagnosis Code (K2091)
            logger.info("Code (K2091) Added")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("button", name="OK").click()
            logger.info("Adding Diagnosis Code - K2211")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("button", name="Add Diagnosis").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").fill("K2211")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").press("Enter") # Add Diagnosis Code (K2211)
            logger.info("Code (K2211) Added")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("button", name="OK").click()
            logger.info("Adding CPT Code - 0DB58ZX")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("button", name="Add Procedure").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").fill("0DB58ZX")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Enter Keyword or Code:").press("Enter") # Add CPT Code (0DB58ZX)
            logger.info("CPT Code (0DB58ZX) Added")
            logger.info("Deleting Diagnosis Code - K2091")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_text("PrincipalEsophagitis,").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_text("PrincipalEsophagitis,").click(button="right")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_text("Delete Code(s)").click() # Delete Diagnosis Code (K2091)
            page2.wait_for_timeout(1000)
            logger.info("Diagnosis Code (K2091) Deleted")
            screenshot(page2, "codeset_added")

            end_step()
        # Add Provider Episode to CPT Codes
            section_break("Add Provider Procedure to CPT Code")
            step("Add Dr Episode to CPT Codes", "Adding Procedure Episode to CPT Codes")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_text("PrincipalExcision of").click()
            page2.wait_for_timeout(1000)            
            frames2.codefinder_popout.get_by_text("PrincipalExcision of").click(button="right")
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("menuitem", name="Add Date/Physician/Episode").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Start Date").click()
            page2.wait_for_timeout(1000)
            
            manual_prompt(
                message="Select Date for Provider Episode",
                completion_note="Provider Episode Date Entered"
            )

            logger.info("Procedure Date Selected....Continuing Automation")
            frames2.codefinder_popout.get_by_role("textbox", name="Start Date").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Start Date").press("Tab")
            page2.wait_for_timeout(1000)

            try:
                frames2.crs_popout.get_by_label("Self Pay").press("Tab")
                logger.info("Navigating to Physician")
            except Exception as e:
                    logger.error(f"Did Not Correctly Bypass Self Pay Option | {str(e)}")
                    manual_prompt(
                        message="Unable to bypass Self Pay. Hit Continue in Orbit and Automation will pick up at Physician properly.",
                        completion_note="Continuning Run"
                    )
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Physician").click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("textbox", name="Physician").fill(admitting_md)
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("cell").filter(has_text=admitting_md).first.click()
            page2.wait_for_timeout(1000)
            frames2.codefinder_popout.get_by_role("button", name="OK").click()
            page2.wait_for_timeout(1000)
            screenshot(page2, "codeset_with_providerep_added")
            logger.info("Provider Episode Successfully Added")
            end_step()
        # Pop In Codefinder
            section_break("Pop In to Window")
            step("Pop In", "Popping Back Into Window")
            page2.wait_for_timeout(1000)
            page2.get_by_role("button", name=" Pop-In").click()
            logger.info("Page Popped in Successfully")
            screenshot(page1, "popped_in")

            end_step()  
        # Resolve Critical Error
            section_break("Resolve Critical Error")
            step("Resolve Error", "Resolving Critical Error")
            page1.wait_for_timeout(1000)
            frames.codefinder_inline.get_by_role("button", name="Resolve").click()
            page1.wait_for_timeout(1000)
            frames.codefinder_inline.get_by_label("To resolve, you need to").select_option("\n13\n")
            page1.wait_for_timeout(1000)
            frames.codefinder_inline.get_by_role("textbox", name="Add additional note").click()
            page1.wait_for_timeout(1000)
            frames.codefinder_inline.get_by_role("textbox", name="Add additional note").fill("\nTEST")
            page1.wait_for_timeout(1000)
            frames.codefinder_inline.get_by_role("button", name="OK").click()
            logger.info("Critical Error Resolved")               
            screenshot(page1, "resolved_error")

            end_step()
        # Add Consulting Provider within Abstract Tab
            section_break("Add Consulting Provider")
            step("Add Consult Provider", "Adding Consulting Providers")  
            logger.info("Selecting Abstract Tab")
            page1.wait_for_timeout(1000)
            page1.get_by_text("Abstract").click() # Select Abstract Tab 
            screenshot(page1, "abstract_tab")
            logger.info("Adding 1st Consulting Provider")    
            page1.wait_for_timeout(1000)
            frames.abstract.get_by_role("button").click()
            page1.wait_for_timeout(1000)
            frames.abstract.locator("c-dropdown div").first.click()
            page1.wait_for_timeout(1000)
            frames.abstract.locator("input[name=\"search\"]").click()                                
            page1.wait_for_timeout(1000)
            frames.abstract.locator("input[name=\"search\"]").fill("Fake, Dictation")                                
            page1.wait_for_timeout(1000)
            frames.abstract.locator("input[name=\"search\"]").press("Enter")                                
            page1.wait_for_timeout(1000)
            frames.abstract.get_by_text("Fake, Dictation, MD").click()
            page1.wait_for_timeout(1000)
            screenshot(page1, "1st_consult_provider")
            frames.abstract.get_by_role("button").filter(has_text="OK").click()
            page1.wait_for_timeout(1000)
        # Manual Prompt - Enter Date

            manual_prompt(
                message="Select Date for Consulting Provider Date",
                completion_note="Date Entered"
            )  

            page1.wait_for_timeout(1000)
            frames.abstract.get_by_role("button").filter(has_text="Save").click()
            page1.wait_for_timeout(1000)
            logger.info("1st Consulting Provider Added")                                
            screenshot(page1, "1st_consult_dr_added")
            logger.info("Adding 2nd Consulting Provider")
            frames.abstract.get_by_role("button").filter(has_text="Add Consulting Provider").click()                                
            page1.wait_for_timeout(1000)
            frames.abstract.locator("c-dropdown div").first.click()                                
            page1.wait_for_timeout(1000)
            frames.abstract.locator("input[name=\"search\"]").click()
            page1.wait_for_timeout(1000)
            frames.abstract.locator("input[name=\"search\"]").fill("Dictation")
            page1.wait_for_timeout(1000)
            frames.abstract.locator("input[name=\"search\"]").press("Enter")                                
            page1.wait_for_timeout(1000)
            frames.abstract.get_by_role("cell", name="Faker, Dictation, MD").locator("div").click()
            page1.wait_for_timeout(1000)
            screenshot(page1, "2nd_consult_provider")
            frames.abstract.get_by_role("button").filter(has_text="OK").click()
        # Manual Prompt - Enter Date
            manual_prompt(
                message="Select Date for Consulting Provider Date", 
                completion_note="Date Entered"
            )                                
            page1.wait_for_timeout(1000)
            frames.abstract.get_by_role("button").filter(has_text="Save").click()
            logger.info("2nd Consulting Provider Added")
            screenshot(page1, "2nd_consult_dr_added")                                
            logger.info("Checking Validation Tab")
            page1.wait_for_timeout(1000)
            page1.get_by_text("Validation").click()
            screenshot(page1, "2nd_validation_tab_check")
            logger.info("Moving Back to Abstract Tab")
            page1.wait_for_timeout(1000)
            page1.get_by_text("Abstract").click() # Select Abstract Tab                                
            logger.info("Update 2nd Provider Entry to Correct Date")
            page1.wait_for_timeout(1000)
            frames.abstract.get_by_role("button").nth(2).click()

            manual_prompt(
                message="Update Date", 
                completion_note="Date Updated"
            )

            page1.wait_for_timeout(1000)
            frames.abstract.get_by_role("button").filter(has_text="Save").click()
            logger.info("2nd Consulting Provider Updated")                                
            screenshot(page1, "2nd_consult_dr_updated")
            logger.info("Checking Validation Tab")
            page1.wait_for_timeout(1000)
            page1.get_by_text("Validation").click() # Select Validation Tab and Validate Error is No Longer Present               
            screenshot(page1, "final_validation_check")
            logger.info("Navigating Back to Documents and Codes Tab")
            page1.wait_for_timeout(1000)
            page1.get_by_text("Documents and Codes").click() # Select Document and Codes Tab                                
            logger.info("Consulting Provider Logic Tested")

            end_step()
         # Complete Account (1st Try)
            section_break("Complete Account - 1st Try")
            step("Complete Account - 1st Attempt", "Completing Account")                                
            page1.wait_for_timeout(1000)
            frames.codefinder_inline.get_by_role("button", name="Complete").click()
    # ==================================================
    # Present on Admission
    # ==================================================
            screenshot(page1, "poa_prompt")
            page1.wait_for_timeout(1000)
            logger.info("Present On Admission Prompt")
            page1.wait_for_timeout(1000)          
            frames.codefinder.get_by_role("button", name="Yes").click()
            manual_prompt(
                message="Select Y, and Ok",
                completion_note="Option Selected"
            )            
            logger.info("POA Added Successfully")
            screenshot(page1, "poa_added")
            logger.info("Attempting to Complete Once More.")                                
            page1.wait_for_timeout(1000)
            frames.codefinder_inline.get_by_role("button", name="Complete").click()
            logger.info("Account has been completed")

            end_step()
    # ==================================================
    # Place Account on Hold
    # ==================================================
            section_break("Place Account on Hold")
            step("Place Account on Hold", "Placing Account on Hold")                                
            logger.info("Moving Account from Ready to Hold")
            page1.wait_for_timeout(1000)
            page1.get_by_text("Ready").first.click()                                
            page1.wait_for_timeout(1000)
            page1.get_by_text("Hold", exact=True).click()                                
            page1.wait_for_timeout(1000)
            frames.hold_dialog.locator("#holdReasonLabel-inputFieldContainer").click()
            page1.wait_for_timeout(1000)
            frames.hold_dialog.locator("#holdReasonLabel-filterInput").click()                                
            page1.wait_for_timeout(1000)
            frames.hold_dialog.locator("#holdReasonLabel-filterInput").fill("3M-3M UPDATE ISSUE")                                
            page1.wait_for_timeout(1000)
            frames.hold_dialog.get_by_role("listitem", name="3M-3M UPDATE ISSUE").locator("div").nth(1).click()                                
            page1.wait_for_timeout(1000)
            frames.hold_dialog.locator("textarea").click()                                
            page1.wait_for_timeout(1000)
            frames.hold_dialog.locator("textarea").fill("TEST")                                
            page1.wait_for_timeout(1000)
            frames.hold_dialog.get_by_role("button").filter(has_text="Hold").click()                                
            logger.info("Account Moved to Hold Status")
            screenshot(page1, "hold_status_update")

            end_step()
    # ==================================================
    # Submit Account (Hold Status)
    # ==================================================
            section_break("Submit Account")
            step("Submit Account", "Submitting Account to Coded Status")                
            page1.wait_for_timeout(1000)
            page1.get_by_role("button", name="Submit").click()
            logger.info("Account Submitted to Hold")
            page1.wait_for_timeout(1000)
            end_step()

    # ==================================================
    # Close Account
    # ==================================================
            section_break("Close Account")
            step("Close Account", "Closing Account")                
            page1.wait_for_timeout(1000)
            page1.get_by_role("button", name="Close").click()
            logger.info("Account Closed")
        page.wait_for_timeout(1000)
        logger.info("Test Passed Successfully!")
        page.close()
        end_step()

    except Exception as e:
        handle_failure(e, page2, page1 or page)

    finally:
        if context:
            save_trace(context)
        if browser:
            browser.close()
        total_duration = time.time() - run_start_time
        logger.info(f"Total Run Duration | {format_duration(total_duration)}")

with sync_playwright() as playwright:
    run(playwright)